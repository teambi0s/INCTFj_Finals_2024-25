# Proxy Search

### Difficulty
easy

### Challenge Description

Afraid of getting caught use our proxy search to be anonymous...

### Short Writeup

+ Use `localh.st` to bypass the check and access `/flag`

### Flag

inctfj{localhost_only_access}

### Author

**exigent07**